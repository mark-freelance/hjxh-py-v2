import os

PROJECT_PATH = os.path.abspath(os.path.dirname(__file__))

CONFIG_PATH = os.path.join(PROJECT_PATH, "config.yaml")
